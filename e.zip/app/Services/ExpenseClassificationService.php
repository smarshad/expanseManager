<?php

namespace App\Services;

class ExpenseClassificationService
{
    private const TRANSACTION_KINDS = [
        'investment' => [
            'investment',
            'ipo',
            'mutual funds',
            'stocks',
        ],
        'transfer' => [
            'credit card bill',
            'withdrawal',
        ],
        'debt' => [
            'return borrow',
        ],
    ];

    private const ESSENTIAL_CATEGORIES = [
        'educate child',
        'gas',
        'gas cylinder',
        'grocery',
        'light bill',
        'maid',
        'medical group',
        'medicine',
        'milk',
        'mobile recharge',
        'petrol',
        'recharge',
        'rent',
        'salma/maid/home',
        'school fees',
        'vegetables',
        'water',
    ];

    private const DISCRETIONARY_CATEGORIES = [
        'entertainment',
        'saloon',
        'shopping',
        'snacks',
        'tea',
    ];

    private const RECURRENCE = [
        'daily' => [
            'milk',
            'tea',
            'travelling',
        ],
        'monthly' => [
            'credit card bill',
            'educate child',
            'light bill',
            'maid',
            'medical group',
            'mobile recharge',
            'mutual funds',
            'recharge',
            'rent',
            'salma/maid/home',
            'school fees',
        ],
    ];

    /**
     * Return only high-confidence classifications. Unknown values stay explicit.
     *
     * @return array{transaction_kind: string, spending_nature: string, recurrence: string}
     */
    public function classify(string $categoryName): array
    {
        $category = mb_strtolower(trim($categoryName));
        $transactionKind = 'expense';

        foreach (self::TRANSACTION_KINDS as $kind => $categories) {
            if (in_array($category, $categories, true)) {
                $transactionKind = $kind;
                break;
            }
        }

        $spendingNature = 'unclassified';
        if ($transactionKind === 'expense') {
            if (in_array($category, self::ESSENTIAL_CATEGORIES, true)) {
                $spendingNature = 'essential';
            } elseif (in_array($category, self::DISCRETIONARY_CATEGORIES, true)) {
                $spendingNature = 'discretionary';
            }
        }

        $recurrence = 'none';
        foreach (self::RECURRENCE as $frequency => $categories) {
            if (in_array($category, $categories, true)) {
                $recurrence = $frequency;
                break;
            }
        }

        return [
            'transaction_kind' => $transactionKind,
            'spending_nature' => $spendingNature,
            'recurrence' => $recurrence,
        ];
    }
}

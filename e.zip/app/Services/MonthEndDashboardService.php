<?php

namespace App\Services;

use App\Models\Budget;
use App\Models\Expense;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class MonthEndDashboardService
{
    private const NET_SQL = 'expenses.amount - COALESCE(expenses.cashback, 0)';

    /**
     * @return array<string, mixed>
     */
    public function generate(int $userId, string $month): array
    {
        $start = Carbon::createFromFormat('Y-m-d', "{$month}-01")->startOfMonth();
        $end = $start->copy()->endOfMonth();
        $base = $this->baseQuery($userId, $start, $end);

        $byKind = (clone $base)
            ->selectRaw('transaction_kind, ROUND(SUM('.self::NET_SQL.'), 2) AS total')
            ->groupBy('transaction_kind')
            ->pluck('total', 'transaction_kind');

        $byNature = (clone $base)
            ->where('transaction_kind', 'expense')
            ->selectRaw('spending_nature, ROUND(SUM('.self::NET_SQL.'), 2) AS total')
            ->groupBy('spending_nature')
            ->pluck('total', 'spending_nature');

        $expenseTotal = $this->money($byKind, 'expense');

        $topCategories = (clone $base)
            ->where('transaction_kind', 'expense')
            ->join('categories', 'expenses.category_id', '=', 'categories.id')
            ->leftJoin('categories as parents', 'categories.parent_id', '=', 'parents.id')
            ->selectRaw(
                'COALESCE(parents.name, categories.name) AS name, '.
                'ROUND(SUM('.self::NET_SQL.'), 2) AS total'
            )
            ->groupByRaw('COALESCE(parents.name, categories.name)')
            ->orderByDesc('total')
            ->limit(10)
            ->get()
            ->map(fn ($row): array => [
                'name' => $row->name,
                'total' => (float) $row->total,
                'percentage' => $expenseTotal > 0
                    ? round(((float) $row->total / $expenseTotal) * 100, 1)
                    : 0,
            ])
            ->all();

        $topVendors = (clone $base)
            ->where('transaction_kind', 'expense')
            ->join('vendors', 'expenses.vendor_id', '=', 'vendors.id')
            ->selectRaw(
                'vendors.name, COUNT(expenses.id) AS transactions, '.
                'ROUND(SUM('.self::NET_SQL.'), 2) AS total'
            )
            ->groupBy('vendors.id', 'vendors.name')
            ->orderByDesc('total')
            ->limit(10)
            ->get()
            ->map(fn ($row): array => [
                'name' => $row->name,
                'transactions' => (int) $row->transactions,
                'total' => (float) $row->total,
            ])
            ->all();

        $unassignedVendorTotal = round((float) (clone $base)
            ->where('transaction_kind', 'expense')
            ->whereNull('vendor_id')
            ->sum(DB::raw(self::NET_SQL)), 2);

        $recurring = (clone $base)
            ->where('transaction_kind', 'expense')
            ->where('recurrence', '!=', 'none')
            ->join('categories', 'expenses.category_id', '=', 'categories.id')
            ->leftJoin('categories as parents', 'categories.parent_id', '=', 'parents.id')
            ->selectRaw(
                'MIN(expenses.description) AS title, expenses.recurrence, '.
                'COALESCE(parents.name, categories.name) AS category, '.
                'COUNT(expenses.id) AS occurrences, '.
                'ROUND(SUM('.self::NET_SQL.'), 2) AS total'
            )
            ->groupByRaw(
                'LOWER(TRIM(expenses.description)), expenses.recurrence, '.
                'COALESCE(parents.name, categories.name)'
            )
            ->orderByDesc('total')
            ->limit(12)
            ->get()
            ->map(fn ($row): array => [
                'title' => $row->title,
                'category' => $row->category,
                'frequency' => $row->recurrence,
                'occurrences' => (int) $row->occurrences,
                'total' => (float) $row->total,
            ])
            ->all();

        return [
            'month' => $month,
            'period_label' => $start->format('F Y'),
            "summary" => [
                "expenses" => $expenseTotal,
                "investments" => $this->money($byKind, "investment"),
                "total_expense_including_investment" => round(
                    $expenseTotal + $this->money($byKind, "investment"),
                    2
                ),
                "transfers" => $this->money($byKind, "transfer"),
                "debt" => $this->money($byKind, "debt"),
                "need" => $this->money($byNature, "essential"),
                "want" => $this->money($byNature, "discretionary"),
                "unclassified" => $this->money($byNature, "unclassified"),
            ],
            'expense_breakdown' => [
                ['label' => 'Actual Expenses', 'total' => $expenseTotal],
                ['label' => 'Investments', 'total' => $this->money($byKind, 'investment')],
                ['label' => 'Transfers', 'total' => $this->money($byKind, 'transfer')],
                ['label' => 'Debt Repayment', 'total' => $this->money($byKind, 'debt')],
            ],
            'top_categories' => $topCategories,
            'need_vs_want' => [
                'need' => $this->money($byNature, 'essential'),
                'want' => $this->money($byNature, 'discretionary'),
                'unclassified' => $this->money($byNature, 'unclassified'),
            ],
            'top_vendors' => $topVendors,
            'unassigned_vendor_total' => $unassignedVendorTotal,
            'budget_alerts' => $this->budgetAlerts($userId, $start, $base),
            'recurring_expenses' => $recurring,
        ];
    }

    private function baseQuery(int $userId, Carbon $start, Carbon $end): Builder
    {
        return Expense::query()
            ->where('expenses.created_by', $userId)
            ->whereBetween('expenses.expense_date', [
                $start->toDateString(),
                $end->toDateString(),
            ]);
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function budgetAlerts(int $userId, Carbon $month, Builder $base): array
    {
        return Budget::query()
            ->with('category.parent')
            ->where('user_id', $userId)
            ->whereDate('month', $month->toDateString())
            ->orderBy('category_id')
            ->get()
            ->map(function (Budget $budget) use ($base): array {
                $categoryIds = $budget->category->parent_id
                    ? collect([$budget->category_id])
                    : $budget->category->children()->pluck('id')->push($budget->category_id);

                $actual = round((float) (clone $base)
                    ->where('transaction_kind', 'expense')
                    ->whereIn('category_id', $categoryIds)
                    ->sum(DB::raw(self::NET_SQL)), 2);
                $limit = (float) $budget->amount;
                $percentage = $limit > 0 ? round(($actual / $limit) * 100, 1) : 0;

                return [
                    'category' => $budget->category->display_name,
                    'limit' => $limit,
                    'actual' => $actual,
                    'remaining' => round($limit - $actual, 2),
                    'percentage' => $percentage,
                    'status' => $percentage >= 100
                        ? 'over'
                        : ($percentage >= 80 ? 'warning' : 'safe'),
                ];
            })
            ->sortByDesc('percentage')
            ->values()
            ->all();
    }

    private function money(Collection $values, string $key): float
    {
        return round((float) $values->get($key, 0), 2);
    }
}

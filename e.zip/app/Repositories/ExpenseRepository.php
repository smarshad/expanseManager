<?php

namespace App\Repositories;

use App\Interfaces\ExpenseRepositoryInterface;
use App\Models\Expense;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Storage;

class ExpenseRepository implements ExpenseRepositoryInterface
{
    public function __construct(protected Expense $model) {}

    public function getAll(): Collection
    {
        return $this->model->all();
    }

    public function create(array $data): Expense
    {
        return $this->model->create($data);
    }

    public function getPaginated(int $perPage = 15, array $columns = ['*'], ?int $userId = null, ?string $search = null): LengthAwarePaginator
    {
        $query = $this->model->with(['creator', 'category.parent', 'paymentMethod', 'account', 'paymentPlatform', 'vendor', 'expenseFor']);

        if ($userId !== null) {
            $query->where('created_by', $userId);
        }

        if ($search) {
            $query->where(function ($query) use ($search) {
                $query->where('description', 'like', "%{$search}%")
                    ->orWhere('amount', 'like', "%{$search}%")
                    ->orWhereHas('category', function ($category) use ($search) {
                        $category->where('name', 'like', "%{$search}%")
                            ->orWhereHas('parent', fn ($parent) => $parent->where('name', 'like', "%{$search}%"));
                    })
                    ->orWhereHas('paymentMethod', fn ($method) => $method->where('name', 'like', "%{$search}%"))
                    ->orWhereHas('account', fn ($account) => $account->where('name', 'like', "%{$search}%"))
                    ->orWhereHas('paymentPlatform', fn ($platform) => $platform->where('name', 'like', "%{$search}%"))
                    ->orWhereHas('vendor', fn ($vendor) => $vendor->where('name', 'like', "%{$search}%"))
                    ->orWhereHas('expenseFor', fn ($expenseFor) => $expenseFor->where('name', 'like', "%{$search}%"));
            });
        }

        return $query->paginate($perPage, $columns);
    }

    public function update(int $id, array $data): Expense
    {
        $expense = $this->findById($id);

        if (array_key_exists('file_path', $data)) {
            $newPath = $data['file_path'];
            $oldPath = $expense->file_path;

            if ($oldPath && $newPath && $oldPath !== $newPath && Storage::disk('public')->exists($oldPath)) {
                Storage::disk('public')->delete($oldPath);
            }
        }

        $expense->update($data);

        return $expense;
    }

    private function findById(int $id): Expense
    {
        return $this->model->findOrFail($id);
    }

    public function delete(int $id): bool
    {
        return (bool) $this->model->destroy($id);
    }
}

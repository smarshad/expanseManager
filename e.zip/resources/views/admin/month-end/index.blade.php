@extends('layoutsnew.app')

@section('title', 'Month-end Dashboard')

@push('styles')
<style>
    .month-end-page .metric-card,
    .month-end-page .section-card {
        border: 0;
        border-radius: 12px;
        box-shadow: 0 3px 14px rgba(31, 45, 61, .08);
    }
    .month-end-page .metric-card {
        border-left: 4px solid #4f46e5;
    }
    .month-end-page .metric-label {
        color: #6c757d;
        font-size: .78rem;
        letter-spacing: .04em;
        text-transform: uppercase;
    }
    .month-end-page .metric-value {
        color: #1f2937;
        font-weight: 700;
    }
    .month-end-page .table td,
    .month-end-page .table th {
        vertical-align: middle;
    }
    .month-end-page .progress {
        background: #edf0f5;
        height: 9px;
    }
    .month-end-page .empty-state {
        color: #6c757d;
        padding: 2rem 1rem;
        text-align: center;
    }
</style>
@endpush

@section('content')
<div class="content month-end-page">
    <div class="container-fluid">
        <div class="row align-items-center mb-3">
            <div class="col">
                <h3 class="mb-1"><i class="fas fa-calendar-check mr-2"></i>Month-end Dashboard</h3>
                <p class="text-muted mb-0">{{ $dashboard['period_label'] }} spending review</p>
            </div>
            <div class="col-auto">
                <form method="GET" action="{{ route('month-end.index') }}" class="form-inline">
                    <label for="dashboardMonth" class="mr-2">Month</label>
                    <input id="dashboardMonth" name="month" type="month" class="form-control mr-2"
                        value="{{ $dashboard['month'] }}">
                    <button class="btn btn-primary" type="submit">View</button>
                </form>
            </div>
        </div>

        @if(session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif
        @if(isset($errors) && $errors->any())
            <div class="alert alert-danger">{{ $errors->first() }}</div>
        @endif

        <div class="row">
            @foreach([
                ["Actual Expense", $dashboard["summary"]["expenses"], "fa-wallet"],
                ["Need", $dashboard["summary"]["need"], "fa-home"],
                ["Want / Saveable", $dashboard["summary"]["want"], "fa-piggy-bank"],
                ["Investment", $dashboard["summary"]["investments"], "fa-chart-line"],
                ["Total Expense + Investment", $dashboard["summary"]["total_expense_including_investment"], "fa-coins"],
            ] as [$label, $value, $icon])
                <div class="col-md-3">
                    <div class="card metric-card">
                        <div class="card-body d-flex justify-content-between align-items-center">
                            <div>
                                <div class="metric-label">{{ $label }}</div>
                                <div class="metric-value h3 mb-0">Rs. {{ number_format($value, 2) }}</div>
                            </div>
                            <i class="fas {{ $icon }} fa-2x text-primary"></i>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>

        <div class="row">
            <div class="col-lg-6">
                <div class="card section-card">
                    <div class="card-header"><h5 class="mb-0">Expense Breakdown</h5></div>
                    <div class="card-body p-0">
                        <table class="table table-hover mb-0">
                            <thead><tr><th>Money Flow</th><th class="text-right">Amount</th></tr></thead>
                            <tbody>
                                @foreach($dashboard['expense_breakdown'] as $row)
                                    <tr>
                                        <td>{{ $row['label'] }}</td>
                                        <td class="text-right">Rs. {{ number_format($row['total'], 2) }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="card section-card">
                    <div class="card-header"><h5 class="mb-0">Need vs Want</h5></div>
                    <div class="card-body">
                        @php
                            $natureTotal = array_sum($dashboard['need_vs_want']);
                        @endphp
                        @foreach([
                            ['Need', 'need', 'bg-success'],
                            ['Want', 'want', 'bg-warning'],
                            ['Review Later', 'unclassified', 'bg-secondary'],
                        ] as [$label, $key, $color])
                            @php
                                $amount = $dashboard['need_vs_want'][$key];
                                $percentage = $natureTotal > 0 ? ($amount / $natureTotal) * 100 : 0;
                            @endphp
                            <div class="mb-3">
                                <div class="d-flex justify-content-between mb-1">
                                    <span>{{ $label }}</span>
                                    <strong>Rs. {{ number_format($amount, 2) }} ({{ number_format($percentage, 1) }}%)</strong>
                                </div>
                                <div class="progress">
                                    <div class="progress-bar {{ $color }}" style="width: {{ min(100, $percentage) }}%"></div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-6">
                <div class="card section-card">
                    <div class="card-header"><h5 class="mb-0">Top Categories</h5></div>
                    <div class="card-body p-0">
                        @if($dashboard['top_categories'])
                            <table class="table table-hover mb-0">
                                <thead><tr><th>Category</th><th>Share</th><th class="text-right">Amount</th></tr></thead>
                                <tbody>
                                    @foreach($dashboard['top_categories'] as $category)
                                        <tr>
                                            <td>{{ $category['name'] }}</td>
                                            <td style="width: 35%">
                                                <div class="progress">
                                                    <div class="progress-bar bg-info" style="width: {{ min(100, $category['percentage']) }}%"></div>
                                                </div>
                                                <small>{{ number_format($category['percentage'], 1) }}%</small>
                                            </td>
                                            <td class="text-right">Rs. {{ number_format($category['total'], 2) }}</td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        @else
                            <div class="empty-state">No expense data for this month.</div>
                        @endif
                    </div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="card section-card">
                    <div class="card-header"><h5 class="mb-0">Top Vendors</h5></div>
                    <div class="card-body p-0">
                        @if($dashboard['top_vendors'])
                            <table class="table table-hover mb-0">
                                <thead><tr><th>Vendor</th><th>Entries</th><th class="text-right">Amount</th></tr></thead>
                                <tbody>
                                    @foreach($dashboard['top_vendors'] as $vendor)
                                        <tr>
                                            <td>{{ $vendor['name'] }}</td>
                                            <td>{{ $vendor['transactions'] }}</td>
                                            <td class="text-right">Rs. {{ number_format($vendor['total'], 2) }}</td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        @else
                            <div class="empty-state">
                                Add Vendor/Merchant while recording expenses to build this report.
                            </div>
                        @endif
                    </div>
                    @if($dashboard['unassigned_vendor_total'] > 0)
                        <div class="card-footer text-warning">
                            Vendor not tagged: Rs. {{ number_format($dashboard['unassigned_vendor_total'], 2) }}
                        </div>
                    @endif
                </div>
            </div>
        </div>

        <div class="card section-card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Budget Alerts</h5>
                <form method="POST" action="{{ route('month-end.budgets.store') }}" class="form-inline">
                    @csrf
                    <input type="hidden" name="month" value="{{ $dashboard['month'] }}">
                    <select name="category_id" class="form-control form-control-sm mr-2" required>
                        <option value="">Category</option>
                        @foreach($categories as $category)
                            <option value="{{ $category->id }}">{{ $category->display_name }}</option>
                        @endforeach
                    </select>
                    <input name="amount" type="number" min="1" step="0.01"
                        class="form-control form-control-sm mr-2" placeholder="Monthly limit" required>
                    <button class="btn btn-sm btn-primary" type="submit">Save Budget</button>
                </form>
            </div>
            <div class="card-body p-0">
                @if($dashboard['budget_alerts'])
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr><th>Category</th><th>Used</th><th>Limit</th><th>Remaining</th><th>Status</th></tr>
                        </thead>
                        <tbody>
                            @foreach($dashboard['budget_alerts'] as $budget)
                                <tr>
                                    <td>{{ $budget['category'] }}</td>
                                    <td>Rs. {{ number_format($budget['actual'], 2) }}</td>
                                    <td>Rs. {{ number_format($budget['limit'], 2) }}</td>
                                    <td class="{{ $budget['remaining'] < 0 ? 'text-danger' : 'text-success' }}">
                                        Rs. {{ number_format($budget['remaining'], 2) }}
                                    </td>
                                    <td style="min-width: 180px">
                                        <div class="progress mb-1">
                                            <div class="progress-bar {{
                                                $budget['status'] === 'over' ? 'bg-danger' :
                                                ($budget['status'] === 'warning' ? 'bg-warning' : 'bg-success')
                                            }}" style="width: {{ min(100, $budget['percentage']) }}%"></div>
                                        </div>
                                        <small>{{ number_format($budget['percentage'], 1) }}% — {{ ucfirst($budget['status']) }}</small>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                @else
                    <div class="empty-state">No budgets set for {{ $dashboard['period_label'] }}.</div>
                @endif
            </div>
        </div>

        <div class="card section-card">
            <div class="card-header"><h5 class="mb-0">Recurring Expenses</h5></div>
            <div class="card-body p-0">
                @if($dashboard['recurring_expenses'])
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr><th>Expense</th><th>Category</th><th>Frequency</th><th>Occurrences</th><th class="text-right">Amount</th></tr>
                        </thead>
                        <tbody>
                            @foreach($dashboard['recurring_expenses'] as $expense)
                                <tr>
                                    <td>{{ $expense['title'] }}</td>
                                    <td>{{ $expense['category'] }}</td>
                                    <td>{{ ucfirst($expense['frequency']) }}</td>
                                    <td>{{ $expense['occurrences'] }}</td>
                                    <td class="text-right">Rs. {{ number_format($expense['total'], 2) }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                @else
                    <div class="empty-state">No recurring expenses recorded for this month.</div>
                @endif
            </div>
        </div>
    </div>
</div>
@endsection

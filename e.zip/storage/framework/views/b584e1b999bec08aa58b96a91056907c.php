<?php
$isEdit = $paymentmethod?->exists;
$action = $isEdit ? route('paymentmethod.update', $paymentmethod) : route('paymentmethod.store');
$method = $isEdit ? 'PUT' : 'POST';
?>

<form id="paymentmethodForm" action="<?php echo e($action); ?>" method="POST" class="data-ajax-submit form-horizontal">
    <?php echo csrf_field(); ?>
    <?php if($isEdit): ?>
    <?php echo method_field('PUT'); ?>
    <?php endif; ?>
    <div class="form-group row">
        <label class="col-md-4 col-form-label" for="name">Name</label>
        <div class="col-md-8">
            <input type="text" id="name" name="name" class="form-control" value="<?php echo e($paymentmethod && $paymentmethod->exists ? $paymentmethod->name : ''); ?>" placeholder="Lunch, Dinner">
        </div>
    </div>

    <div class="form-group row">
        <label class="col-md-4 col-form-label" for="code">Code</label>
        <div class="col-md-8">
            <input type="text" id="code" name="code" class="form-control" placeholder="code" value="<?php echo e(isset($paymentmethod) ? $paymentmethod->code : ''); ?>">
        </div>
    </div>
</form><?php /**PATH /home/arshad/Downloads/laravel/projects/expanseManager/resources/views/admin/paymentmethod/_form.blade.php ENDPATH**/ ?>
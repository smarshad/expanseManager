<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
    <meta content="Coderthemes" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="perPage" content="<?php echo e(config('pagination.default')); ?>">

    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('backend/images/favicon.ico')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
    <!-- App css -->
    <link href="<?php echo e(asset('backend/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" id="bootstrap-stylesheet" />
    <link href="<?php echo e(asset('backend/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('backend/css/app.min.css')); ?>" rel="stylesheet" type="text/css"  id="app-stylesheet" />
    <style>
        .pt-10{padding-top: 10px;}
        #sidebar-menu>ul>li>a{font-size:14px !important}
    </style>
</head>

<body>
    <div id="wrapper">
        <?php echo $__env->make('admin.partials.topnavbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('admin.partials.leftnavbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="content-page">
            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->
            <?php echo $__env->yieldContent('content'); ?>
            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->
        </div>
        <!-- Footer Start -->
        <?php echo $__env->make('admin.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- end Footer -->
        <?php echo $__env->make('admin.includes.modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
    <!-- end page -->

    <!-- Vendor js -->
    <script src="<?php echo e(asset('backend/js/vendor.min.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>

    <!-- App js -->
    <script src="<?php echo e(asset('backend/js/app.min.js')); ?>"></script>
</body>

</html><?php /**PATH /home/arshad/Downloads/laravel/projects/expanseManager/resources/views/layoutsnew/app.blade.php ENDPATH**/ ?>
<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('backend/libs/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('backend/libs/datatables/dataTables.bootstrap4.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="content"><div class="container-fluid">
<div class="page-title-box"><h4 class="page-title">Accounts</h4></div>
<div class="card-box table-responsive">
<input type="hidden" id="listRoute" value="<?php echo e(route('account.list')); ?>">
<div class="d-flex justify-content-between mb-3"><h4 class="header-title">All Accounts</h4>
<button class="btn btn-primary btn-sm openModel" data-url="<?php echo e(route('account.create')); ?>" data-size="lg" data-title="Create Account" data-footer='<button class="btn btn-primary js-submit-btn">Create</button> <button class="btn btn-info" data-dismiss="modal">Close</button>'>+ Create New</button></div>
<?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<table id="datatable" class="table table-bordered" style="width:100%"><thead><tr>
<th>Sr No</th><th>Account</th><th>Bank</th><th>Type</th><th>Opening Balance</th><th>Methods</th><th>Platforms</th><th>Active</th><th>Action</th>
</tr></thead><tbody></tbody></table>
</div></div></div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('backend/libs/sweetalert2/sweetalert2.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/libs/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/libs/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<script>window.masterConfig={edit:<?php echo json_encode(route('account.edit', ':id'), 512) ?>,delete:<?php echo json_encode(route('account.destroy', ':id'), 512) ?>,title:'Account',columns:[{data:'name'},{data:'bank_name',defaultContent:'-'},{data:'account_type'},{data:'opening_balance'},{data:'methods'},{data:'platforms',defaultContent:'-'},{data:'is_active',render:v=>v?'Yes':'No'}]};</script>
<script src="<?php echo e(asset('backend/js/manage-linked-master.js')); ?>"></script><script src="<?php echo e(asset('backend/js/ajax-form-submit.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layoutsnew.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/arshad/Downloads/laravel/projects/expanseManager/resources/views/admin/account/index.blade.php ENDPATH**/ ?>
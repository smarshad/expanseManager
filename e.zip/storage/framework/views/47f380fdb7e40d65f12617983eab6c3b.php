<?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<?php if(!$menu->route && $menu->childrenRecursive->isEmpty() && !$menu->url): ?>
<?php continue; ?>
<?php endif; ?>

<li>
    <a href="<?php echo e($menu->route ? route($menu->route) : 'javascript:void(0);'); ?>">
        <?php if($menu->icon): ?>
        <i class="<?php echo e($menu->icon); ?>"></i>
        <?php endif; ?>

        <span><?php echo e($menu->name); ?></span>

        <?php if($menu->childrenRecursive->isNotEmpty()): ?>
        <span class="menu-arrow"></span>
        <?php endif; ?>
    </a>

    <?php if($menu->childrenRecursive->isNotEmpty()): ?>
    <ul class="nav-second-level" aria-expanded="false">
        <?php echo $__env->make('admin.partials.sidebar-menu', [
        'menus' => $menu->childrenRecursive
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </ul>
    <?php endif; ?>
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /home/arshad/Downloads/laravel/projects/expanseManager/resources/views/admin/partials/sidebar-menu.blade.php ENDPATH**/ ?>
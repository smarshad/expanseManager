<?php
    $isEdit = $vendor?->exists;
    $action = $isEdit ? route('vendor.update', $vendor) : route('vendor.store');
?>

<form action="<?php echo e($action); ?>" method="POST" class="data-ajax-submit form-horizontal">
    <?php echo csrf_field(); ?>
    <?php if($isEdit): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <div class="form-group row">
        <label class="col-md-4 col-form-label" for="name">Vendor Name</label>
        <div class="col-md-8">
            <input type="text" id="name" name="name" class="form-control"
                value="<?php echo e(old('name', $vendor->name ?? '')); ?>"
                placeholder="DMart, Amazon, Local Grocery Shop">
        </div>
    </div>

    <div class="form-group row">
        <label class="col-md-4 col-form-label" for="category_id">Default Category</label>
        <div class="col-md-8">
            <select id="category_id" name="category_id" class="form-control">
                <option value="">No default category</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>" <?php if(old('category_id', $vendor->category_id ?? null) == $category->id): echo 'selected'; endif; ?>>
                        <?php echo e($category->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <div class="form-group row">
        <label class="col-md-4 col-form-label" for="is_active">Active</label>
        <div class="col-md-8 pt-2">
            <div class="custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input" id="is_active" name="is_active" value="1"
                    <?php echo e(old('is_active', $vendor->is_active ?? true) ? 'checked' : ''); ?>>
                <label class="custom-control-label" for="is_active">Available in expense form</label>
            </div>
        </div>
    </div>
</form>
<?php /**PATH /home/arshad/Downloads/laravel/projects/expanseManager/resources/views/admin/vendor/_form.blade.php ENDPATH**/ ?>
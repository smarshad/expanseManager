<!-- Begin page -->

<?php $__env->startSection('content'); ?>
<div class="content">

    <!-- Start Content-->
    <div class="container-fluid">

        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Adminox</a></li>
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                            <li class="breadcrumb-item active">Dashboard 2</li>
                        </ol>
                    </div>
                    <h4 class="page-title">Dashboard 2</h4>
                </div>
            </div>
        </div>
        <!-- end page title -->

        <div class="row">
            <div class="card-body">
                <form id="backupForm">
                    <?php echo csrf_field(); ?>

                    
                    <div class="mb-3">
                        <label class="form-label">Tables <span class="text-danger">*</span></label>
                        <select name="tables[]" multiple class="form-control" required>
                            <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($table); ?>"><?php echo e($table); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <small class="text-muted">Hold Ctrl / Cmd to select multiple</small>
                    </div>

                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">From Date</label>
                            <input type="date" name="from" class="form-control">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">To Date</label>
                            <input type="date" name="to" class="form-control">
                        </div>
                    </div>

                    
                    <div class="mb-3">
                        <label class="form-label">Created By (User ID)</label>
                        <input type="number" name="created_by" class="form-control" placeholder="Optional">
                    </div>

                    
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-danger" id="backupBtn">
                            Generate & Download Backup
                        </button>

                        <span id="backupStatus" class="text-muted align-self-center"></span>
                    </div>
                </form>
            </div>

        </div>
        <!-- end row -->

    </div> <!-- end container-fluid -->

</div> <!-- end content -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
document.getElementById('backupForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const form = e.target;
    const btn = document.getElementById('backupBtn');
    const status = document.getElementById('backupStatus');

    btn.disabled = true;
    status.textContent = 'Generating backup... please wait';

    fetch('<?php echo e(route("db.backup.store")); ?>', {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': document.querySelector('input[name=_token]').value,
            'Accept': 'application/json'
        },
        body: new FormData(form)
    })
    .then(res => res.json())
    .then(data => {
        if (data.download_url) {
            status.textContent = 'Download started';
            window.location.href = data.download_url;
        } else {
            status.textContent = 'Backup queued';
        }
    })
    .catch(err => {
        console.error(err);
        alert('Backup failed');
        status.textContent = '';
    })
    .finally(() => {
        btn.disabled = false;
    });
});
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layoutsnew.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/arshad/Downloads/laravel/projects/expanseManager/resources/views/admin/database-backup.blade.php ENDPATH**/ ?>
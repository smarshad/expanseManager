<?php $__env->startSection('title', 'Month-end Dashboard'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .month-end-page .metric-card,
    .month-end-page .section-card {
        border: 0;
        border-radius: 12px;
        box-shadow: 0 3px 14px rgba(31, 45, 61, .08);
    }
    .month-end-page .metric-card {
        border-left: 4px solid #4f46e5;
    }
    .month-end-page .metric-label {
        color: #6c757d;
        font-size: .78rem;
        letter-spacing: .04em;
        text-transform: uppercase;
    }
    .month-end-page .metric-value {
        color: #1f2937;
        font-weight: 700;
    }
    .month-end-page .table td,
    .month-end-page .table th {
        vertical-align: middle;
    }
    .month-end-page .progress {
        background: #edf0f5;
        height: 9px;
    }
    .month-end-page .empty-state {
        color: #6c757d;
        padding: 2rem 1rem;
        text-align: center;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="content month-end-page">
    <div class="container-fluid">
        <div class="row align-items-center mb-3">
            <div class="col">
                <h3 class="mb-1"><i class="fas fa-calendar-check mr-2"></i>Month-end Dashboard</h3>
                <p class="text-muted mb-0"><?php echo e($dashboard['period_label']); ?> spending review</p>
            </div>
            <div class="col-auto">
                <form method="GET" action="<?php echo e(route('month-end.index')); ?>" class="form-inline">
                    <label for="dashboardMonth" class="mr-2">Month</label>
                    <input id="dashboardMonth" name="month" type="month" class="form-control mr-2"
                        value="<?php echo e($dashboard['month']); ?>">
                    <button class="btn btn-primary" type="submit">View</button>
                </form>
            </div>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(isset($errors) && $errors->any()): ?>
            <div class="alert alert-danger"><?php echo e($errors->first()); ?></div>
        <?php endif; ?>

        <div class="row">
            <?php $__currentLoopData = [
                ["Actual Expense", $dashboard["summary"]["expenses"], "fa-wallet"],
                ["Need", $dashboard["summary"]["need"], "fa-home"],
                ["Want / Saveable", $dashboard["summary"]["want"], "fa-piggy-bank"],
                ["Investment", $dashboard["summary"]["investments"], "fa-chart-line"],
                ["Total Expense + Investment", $dashboard["summary"]["total_expense_including_investment"], "fa-coins"],
            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $value, $icon]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3">
                    <div class="card metric-card">
                        <div class="card-body d-flex justify-content-between align-items-center">
                            <div>
                                <div class="metric-label"><?php echo e($label); ?></div>
                                <div class="metric-value h3 mb-0">Rs. <?php echo e(number_format($value, 2)); ?></div>
                            </div>
                            <i class="fas <?php echo e($icon); ?> fa-2x text-primary"></i>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="row">
            <div class="col-lg-6">
                <div class="card section-card">
                    <div class="card-header"><h5 class="mb-0">Expense Breakdown</h5></div>
                    <div class="card-body p-0">
                        <table class="table table-hover mb-0">
                            <thead><tr><th>Money Flow</th><th class="text-right">Amount</th></tr></thead>
                            <tbody>
                                <?php $__currentLoopData = $dashboard['expense_breakdown']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($row['label']); ?></td>
                                        <td class="text-right">Rs. <?php echo e(number_format($row['total'], 2)); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="card section-card">
                    <div class="card-header"><h5 class="mb-0">Need vs Want</h5></div>
                    <div class="card-body">
                        <?php
                            $natureTotal = array_sum($dashboard['need_vs_want']);
                        ?>
                        <?php $__currentLoopData = [
                            ['Need', 'need', 'bg-success'],
                            ['Want', 'want', 'bg-warning'],
                            ['Review Later', 'unclassified', 'bg-secondary'],
                        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $key, $color]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $amount = $dashboard['need_vs_want'][$key];
                                $percentage = $natureTotal > 0 ? ($amount / $natureTotal) * 100 : 0;
                            ?>
                            <div class="mb-3">
                                <div class="d-flex justify-content-between mb-1">
                                    <span><?php echo e($label); ?></span>
                                    <strong>Rs. <?php echo e(number_format($amount, 2)); ?> (<?php echo e(number_format($percentage, 1)); ?>%)</strong>
                                </div>
                                <div class="progress">
                                    <div class="progress-bar <?php echo e($color); ?>" style="width: <?php echo e(min(100, $percentage)); ?>%"></div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-6">
                <div class="card section-card">
                    <div class="card-header"><h5 class="mb-0">Top Categories</h5></div>
                    <div class="card-body p-0">
                        <?php if($dashboard['top_categories']): ?>
                            <table class="table table-hover mb-0">
                                <thead><tr><th>Category</th><th>Share</th><th class="text-right">Amount</th></tr></thead>
                                <tbody>
                                    <?php $__currentLoopData = $dashboard['top_categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($category['name']); ?></td>
                                            <td style="width: 35%">
                                                <div class="progress">
                                                    <div class="progress-bar bg-info" style="width: <?php echo e(min(100, $category['percentage'])); ?>%"></div>
                                                </div>
                                                <small><?php echo e(number_format($category['percentage'], 1)); ?>%</small>
                                            </td>
                                            <td class="text-right">Rs. <?php echo e(number_format($category['total'], 2)); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <div class="empty-state">No expense data for this month.</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="card section-card">
                    <div class="card-header"><h5 class="mb-0">Top Vendors</h5></div>
                    <div class="card-body p-0">
                        <?php if($dashboard['top_vendors']): ?>
                            <table class="table table-hover mb-0">
                                <thead><tr><th>Vendor</th><th>Entries</th><th class="text-right">Amount</th></tr></thead>
                                <tbody>
                                    <?php $__currentLoopData = $dashboard['top_vendors']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($vendor['name']); ?></td>
                                            <td><?php echo e($vendor['transactions']); ?></td>
                                            <td class="text-right">Rs. <?php echo e(number_format($vendor['total'], 2)); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <div class="empty-state">
                                Add Vendor/Merchant while recording expenses to build this report.
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php if($dashboard['unassigned_vendor_total'] > 0): ?>
                        <div class="card-footer text-warning">
                            Vendor not tagged: Rs. <?php echo e(number_format($dashboard['unassigned_vendor_total'], 2)); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="card section-card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Budget Alerts</h5>
                <form method="POST" action="<?php echo e(route('month-end.budgets.store')); ?>" class="form-inline">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="month" value="<?php echo e($dashboard['month']); ?>">
                    <select name="category_id" class="form-control form-control-sm mr-2" required>
                        <option value="">Category</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->display_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <input name="amount" type="number" min="1" step="0.01"
                        class="form-control form-control-sm mr-2" placeholder="Monthly limit" required>
                    <button class="btn btn-sm btn-primary" type="submit">Save Budget</button>
                </form>
            </div>
            <div class="card-body p-0">
                <?php if($dashboard['budget_alerts']): ?>
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr><th>Category</th><th>Used</th><th>Limit</th><th>Remaining</th><th>Status</th></tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $dashboard['budget_alerts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $budget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($budget['category']); ?></td>
                                    <td>Rs. <?php echo e(number_format($budget['actual'], 2)); ?></td>
                                    <td>Rs. <?php echo e(number_format($budget['limit'], 2)); ?></td>
                                    <td class="<?php echo e($budget['remaining'] < 0 ? 'text-danger' : 'text-success'); ?>">
                                        Rs. <?php echo e(number_format($budget['remaining'], 2)); ?>

                                    </td>
                                    <td style="min-width: 180px">
                                        <div class="progress mb-1">
                                            <div class="progress-bar <?php echo e($budget['status'] === 'over' ? 'bg-danger' :
                                                ($budget['status'] === 'warning' ? 'bg-warning' : 'bg-success')); ?>" style="width: <?php echo e(min(100, $budget['percentage'])); ?>%"></div>
                                        </div>
                                        <small><?php echo e(number_format($budget['percentage'], 1)); ?>% — <?php echo e(ucfirst($budget['status'])); ?></small>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="empty-state">No budgets set for <?php echo e($dashboard['period_label']); ?>.</div>
                <?php endif; ?>
            </div>
        </div>

        <div class="card section-card">
            <div class="card-header"><h5 class="mb-0">Recurring Expenses</h5></div>
            <div class="card-body p-0">
                <?php if($dashboard['recurring_expenses']): ?>
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr><th>Expense</th><th>Category</th><th>Frequency</th><th>Occurrences</th><th class="text-right">Amount</th></tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $dashboard['recurring_expenses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($expense['title']); ?></td>
                                    <td><?php echo e($expense['category']); ?></td>
                                    <td><?php echo e(ucfirst($expense['frequency'])); ?></td>
                                    <td><?php echo e($expense['occurrences']); ?></td>
                                    <td class="text-right">Rs. <?php echo e(number_format($expense['total'], 2)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="empty-state">No recurring expenses recorded for this month.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layoutsnew.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/arshad/Downloads/laravel/projects/expanseManager/resources/views/admin/month-end/index.blade.php ENDPATH**/ ?>
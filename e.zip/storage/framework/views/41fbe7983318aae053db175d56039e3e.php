<?php
    $isEdit = $expensetype?->exists;
    $action = $isEdit ? route('expensetype.update', $expensetype) : route('expensetype.store');
    $method = $isEdit ? 'PUT' : 'POST';
?>

<form id="expensetypeForm" action="<?php echo e($action); ?>" method="POST" class="data-ajax-submit form-horizontal">
    <?php echo csrf_field(); ?>
    <?php if($isEdit): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>
    <div class="form-group row">
        <label class="col-md-4 col-form-label" for="name">Name</label>
        <div class="col-md-8">
            <input type="text" id="name" name="name" class="form-control" value="<?php echo e($expensetype && $expensetype->exists ? $expensetype->name : ''); ?>" placeholder="Lunch, Dinner">
        </div>
    </div>
   
    <div class="form-group row">
        <label class="col-md-4 col-form-label" for="description">Description</label>
        <div class="col-md-8">
            <textarea id="description" name="description" class="form-control" placeholder="description"><?php echo e(isset($expensetype) ? $expensetype->description : ''); ?></textarea>
        </div>
    </div>
</form><?php /**PATH /home/arshad/Downloads/laravel/projects/expanseManager/resources/views/admin/expensetype/_form.blade.php ENDPATH**/ ?>
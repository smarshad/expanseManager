<?php $__env->startSection('content'); ?>
<div class="content">

    <!-- Start Content-->
    <div class="container-fluid">

        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Adminox</a></li>
                            <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e(__('roles.title')); ?></a></li>
                            <li class="breadcrumb-item active">New</li>
                        </ol>
                    </div>
                    <h4 class="page-title"><?php echo e(__('roles.title')); ?></h4>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="card-box">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="header-title mb-3"><?php echo e(__('roles.edit_title')); ?></h4>
                        <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-primary">
                            <?php echo e(__('global.back')); ?>

                        </a>
                    </div>
                    <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>

                    <form id="editRoleForm" action="<?php echo e(route('roles.store')); ?>" method="POST" class="data-ajax-submit form-horizontal">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label for="name" class="col-3 col-form-label">Name</label>
                            <div class="col-3">
                                <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name')); ?>" placeholder="create user">
                            </div>

                            <label for="description" class="col-3 col-form-label">Description</label>
                            <div class="col-3">
                                <input type="text" class="form-control" id="description" name="description" value="<?php echo e(old('description')); ?>" placeholder="create new user">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="mb-3 col-12">
                                <strong>Permissions:</strong>
                                <br />
                                <?php $__currentLoopData = $permissionsGrouped; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module => $permissions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="">
                                    
                                    <hr />
                                    <div class="form-check mb-2">
                                        <input type="checkbox"
                                            id="module-<?php echo e(\Illuminate\Support\Str::slug($module)); ?>"
                                            class="form-check-input module-checkbox"
                                            data-module="<?php echo e(\Illuminate\Support\Str::slug($module)); ?>">

                                        <label class="form-check-label font-weight-bold text-dark"
                                            for="module-<?php echo e(\Illuminate\Support\Str::slug($module)); ?>">
                                            <?php echo e(ucfirst($module)); ?>

                                        </label>
                                    </div>

                                    
                                    <div class="row ml-3">
                                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-6 col-md-3 mb-2">
                                            <div class="form-check">
                                                <input type="checkbox"
                                                    name="permissions[]"
                                                    value="<?php echo e($permission->id); ?>"
                                                    id="permission-<?php echo e($permission->id); ?>"
                                                    class="form-check-input permission-checkbox"
                                                    data-module="<?php echo e(\Illuminate\Support\Str::slug($module)); ?>"
                                                    <?php echo e(isset($rolePermissions) && in_array($permission->id, $rolePermissions) ? 'checked' : ''); ?>>

                                                <label class="form-check-label text-muted"
                                                    for="permission-<?php echo e($permission->id); ?>">
                                                    <?php echo e($permission->name); ?>

                                                </label>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                        <div class="form-group mb-0 row">
                            <div class="offset-3 col-9">
                                <button type="submit" class="btn btn-info waves-effect waves-light"><?php echo e(__('global.save')); ?></button>

                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('backend/js/permission-checkbox.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/ajax-form-submit.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layoutsnew.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/arshad/Downloads/laravel/projects/expanseManager/resources/views/admin/roles/create.blade.php ENDPATH**/ ?>
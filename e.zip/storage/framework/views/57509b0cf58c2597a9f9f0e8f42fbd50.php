<div class="home-btn d-none d-sm-block">
    <a href="<?php echo e(route('login')); ?>"><i class="fas fa-home h2 text-white"></i></a>
</div>
<?php $__env->startSection('content'); ?>
<div class="account-pages w-100 mt-5 mb-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6 col-xl-5">
                <div class="card mb-0">
                    <div class="card-body p-4">
                        <div class="account-box">
                            <div class="account-logo-box">
                                <div class="text-center">
                                    <a href="index.html">
                                        <img src="<?php echo e(asset('backend/images/logo-dark.png')); ?>" alt="" height="30">
                                    </a>
                                </div>
                            </div>
                            <div class="account-content mt-4">
                                <div class="text-center mb-3">
                                    <div class="mb-3">
                                        <img src="<?php echo e(asset('backend//images/users/avatar-5.jpg')); ?>" class="rounded-circle img-thumbnail avatar-lg" alt="thumbnail">
                                    </div>

                                    <p class="text-muted mb-0 font-13">Enter your password to access the admin. </p>
                                </div>
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">    
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <form class="form-horizontal" method="POST" action="<?php echo e(route('lock.unlock')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group row">
                                        <div class="col-12">
                                            <label for="password">Password</label>
                                            <input class="form-control" name="password" type="password" autofocus required id="password" placeholder="Enter your password">
                                        </div>
                                    </div>
                                    <div class="form-group row text-center mt-2">
                                        <div class="col-12">
                                            <button class="btn btn-md btn-block btn-primary waves-effect waves-light" type="submit">Unlock</button>
                                        </div>
                                    </div>
                                </form>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end card-body -->
        </div>
        <!-- end row -->
    </div>
    <!-- end container -->
</div>
<!-- end page -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutsnew.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/arshad/Downloads/laravel/projects/expanseManager/resources/views/newauth/lock.blade.php ENDPATH**/ ?>
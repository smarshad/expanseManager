<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title><?php echo $__env->yieldContent('title', 'Authentication'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
    <meta content="Coderthemes" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('backend/assets/images/favicon.ico')); ?>">

    <!-- App css -->
    <link href="<?php echo e(asset('backend/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" id="bootstrap-stylesheet" />
    <link href="<?php echo e(asset('backend/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('backend/css/app.min.css')); ?>" rel="stylesheet" type="text/css"  id="app-stylesheet" />
    <?php echo $__env->yieldPushContent('styles'); ?>

</head>

<body <?php echo $bodyCss ?? ''; ?>>

    <?php echo $__env->yieldContent('content'); ?>
    <!-- end page -->

    <!-- Vendor js -->
    <script src="<?php echo e(asset('backend/js/vendor.min.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>

    <!-- App js -->
    <script src="<?php echo e(asset('backend/js/app.min.js')); ?>"></script>
</body>

</html><?php /**PATH /home/arshad/Downloads/laravel/projects/expanseManager/resources/views/layoutsnew/auth.blade.php ENDPATH**/ ?>
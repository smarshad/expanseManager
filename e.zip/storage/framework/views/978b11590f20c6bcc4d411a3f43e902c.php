<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('backend/libs/select2/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('backend/libs/bootstrap-select/bootstrap-select.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('backend/libs/select2/select2.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php
// Determine if we are in edit mode. Assume $expense is passed for editing.
$isEdit = isset($expense) && $expense->id;
$formAction = $isEdit ? route('expense.update', $expense->id) : route('expense.store');
$pageTitle = $isEdit ? __('expense.edit_title') : __('expense.create_title');
$breadcrumbActive = $isEdit ? 'Edit' : 'New';
$buttonText = $isEdit ? __('global.update') : __('global.save');
$canSubmit = $isEdit ? Gate::allows('update', $expense) : Gate::allows('create', App\Models\Expense::class);
?>

<?php $__env->startSection('content'); ?>
<div class="content">

    <!-- Start Content-->
    <div class="container-fluid">

        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Adminox</a></li>
                            <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e(__('expense.title')); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo e($breadcrumbActive); ?></li>
                        </ol>
                    </div>
                    <h4 class="page-title"><?php echo e(__('expense.title')); ?></h4>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="card-box">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="header-title mb-3"><?php echo e($pageTitle); ?></h4>
                        <a href="<?php echo e(route('expense.index')); ?>" class="btn btn-primary">
                            <?php echo e(__('global.back')); ?>

                        </a>
                    </div>
                    <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>

                    <form id="editRoleForm" action="<?php echo e($formAction); ?>" method="POST" class="data-ajax-submit form-horizontal" <?php if($isEdit): ?> enctype="multipart/form-data" <?php endif; ?>>
                        <?php echo csrf_field(); ?>
                        <?php if($isEdit): ?>
                        <?php echo method_field('PUT'); ?>
                        <?php endif; ?>

                        <?php if(!$canSubmit): ?>
                            <p class="text-danger d-block mt-1">
                                You do not have permission to <?php echo e($isEdit ? 'update' : 'create'); ?> this expense.
                            </p>
                        <?php endif; ?>
                        <div class="form-group row">
                            <label for="category_id" class="col-3 col-form-label">Select Category</label>
                            <?php if($categories->isNotEmpty()): ?>
                            <div class="col-3">
                                <select name="category_id" id="category_id" class="form-control" data-toggle="select2">
                                    <option value="">Select Category / Sub Category</option>
                                    <?php $__currentLoopData = $categories->whereNull('parent_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($parent->id); ?>" <?php if(old('category_id', $expense->category_id ?? null) == $parent->id): ?> selected <?php endif; ?>><?php echo e($parent->name); ?></option>
                                        <?php $__currentLoopData = $categories->where('parent_id', $parent->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($child->id); ?>" <?php if(old('category_id', $expense->category_id ?? null) == $child->id): ?> selected <?php endif; ?>>&nbsp;&nbsp;— <?php echo e($child->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <?php endif; ?>

                            <label for="expense_for_id" class="col-3 col-form-label">Expense For</label>
                            <?php if($expenseFors->isNotEmpty()): ?>
                            <div class="col-3">
                                <select name="expense_for_id" id="expense_for_id" class="form-control" data-toggle="select2">
                                    <option value="">Expense For</option>
                                    <?php $__currentLoopData = $expenseFors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expenseFor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($expenseFor->id); ?>" <?php if(old('expense_for_id', $expense->expense_for_id ?? null) == $expenseFor->id): ?> selected <?php endif; ?>><?php echo e($expenseFor->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group row">
                            <label for="payment_method_id" class="col-3 col-form-label">Payment Method</label>
                            <div class="col-3">
                                <select name="payment_method_id" id="payment_method_id" class="form-control" data-toggle="select2">
                                    <option value="">Select Payment Method</option>
                                    <?php $__currentLoopData = $paymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentMethod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($paymentMethod->id); ?>" <?php if(old('payment_method_id', $expense->payment_method_id ?? null) == $paymentMethod->id): echo 'selected'; endif; ?>><?php echo e($paymentMethod->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <label for="payment_platform_id" id="payment_platform_label" class="col-3 col-form-label">Payment Platform</label>
                            <div class="col-3" id="payment_platform_group">
                                <select name="payment_platform_id" id="payment_platform_id" class="form-control" data-toggle="select2"><option value="">Select Platform</option></select>
                                <small class="text-muted"><a href="<?php echo e(route('payment-platform.index')); ?>">Manage platforms</a></small>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="account_id" class="col-3 col-form-label">Account</label>
                            <div class="col-3">
                                <select name="account_id" id="account_id" class="form-control" data-toggle="select2"><option value="">Select Account</option></select>
                                <small class="text-muted"><a href="<?php echo e(route('account.index')); ?>">Manage accounts</a></small>
                            </div>
                            <label class="col-md-3 col-form-label" for="expense_date">Expense Date</label>
                            <div class="col-md-3">
                                <?php
                                    $defaultDate = date('Y-m-d');
                                    $expenseDateValue = old('expense_date', $expense->expense_date ?? $defaultDate);
                                    if ($expenseDateValue && !is_string($expenseDateValue)) {
                                        $expenseDateValue = $expenseDateValue->format('Y-m-d');
                                    } elseif ($expenseDateValue) {
                                        $expenseDateValue = date('Y-m-d', strtotime($expenseDateValue));
                                    }
                                ?>
                                <input class="form-control" id="expense_date" name="expense_date" type="date" value="<?php echo e($expenseDateValue); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="vendor_id" class="col-3 col-form-label">Vendor</label>
                            <div class="col-3">
                                <select name="vendor_id" id="vendor_id" class="form-control" data-toggle="select2">
                                    <option value="">Select Vendor (Optional)</option>
                                    <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($vendor->id); ?>" <?php if(old('vendor_id', $expense->vendor_id ?? null) == $vendor->id): echo 'selected'; endif; ?>>
                                            <?php echo e($vendor->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <small class="text-muted"><a href="<?php echo e(route('vendor.index')); ?>">Manage vendors</a></small>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="amount" class="col-3 col-form-label">Amount</label>
                            <div class="col-3">
                                <input type="text" class="form-control" id="amount" name="amount" value="<?php echo e(old('amount', $expense->amount ?? '')); ?>" placeholder="Amount">
                            </div>
                            <label for="description" class="col-3 col-form-label">Description</label>
                            <div class="col-3">
                                <input type="text" class="form-control" id="description" name="description" value="<?php echo e(old('description', $expense->description ?? '')); ?>" placeholder="Description">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="cashback" class="col-3 col-form-label">Cashback</label>
                            <div class="col-3">
                                <input type="number" step="0.01" class="form-control" id="cashback" name="cashback" value="<?php echo e(old('cashback', $expense->cashback ?? '')); ?>" placeholder="0.00">
                            </div>
                            <label for="nature" class="col-3 col-form-label">Nature</label>
                            <div class="col-3">
                                <select name="nature" id="nature" class="form-control">
                                    <?php $__currentLoopData = ['need' => 'Need', 'want' => 'Want', 'investment' => 'Investment']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>" <?php if(old('nature', $expense->nature ?? 'need') === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="notes" class="col-3 col-form-label">Notes</label>
                            <div class="col-3">
                                <input type="text" class="form-control" id="notes" name="notes" value="<?php echo e(old('notes', $expense->notes ?? '')); ?>" placeholder="Notes">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="is_recurring" class="col-3 col-form-label">Recurring?</label>
                            <div class="col-3 pt-2">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input" id="is_recurring" name="is_recurring" value="1" <?php echo e(old('is_recurring', $expense->is_recurring ?? false) ? 'checked' : ''); ?>>
                                    <label class="custom-control-label" for="is_recurring">Yes</label>
                                </div>
                            </div>
                            <label for="frequency" class="col-3 col-form-label">Frequency</label>
                            <div class="col-3">
                                <select name="frequency" id="frequency" class="form-control">
                                    <option value="">Select</option>
                                    <?php $__currentLoopData = ['daily' => 'Daily', 'occasionally' => 'Occasionally',  'weekly' => 'Weekly', 'monthly' => 'Monthly', 'quarterly' => 'Quarterly', 'yearly' => 'Yearly']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>" <?php if(old('frequency', $expense->frequency ?? '') === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="uploaded_file" class="col-3 col-form-label">File Path</label>
                            <div class="col-3">
                                <input type="file" class="form-control" id="uploaded_file" name="uploaded_file">
                                <?php if($isEdit && $expense->uploaded_file): ?>
                                <small class="form-text text-muted">Current file: <a href="<?php echo e(asset('path/to/your/files/' . $expense->uploaded_file)); ?>" target="_blank"><?php echo e($expense->uploaded_file); ?></a></small>
                                <?php endif; ?>
                            </div>

                            
                            <?php if($isEdit && $expense->file_path): ?>
                            <label class="col-3 col-form-label">Old File</label>
                            <div class="col-3">
                                <?php
                                // Build public URL for file on 'public' disk. Adjust if you use a different disk.
                                $url = \Illuminate\Support\Facades\Storage::disk('public')->url($expense->file_path);
                                $ext = strtolower(pathinfo($expense->file_path, PATHINFO_EXTENSION));
                                $isImage = in_array($ext, ['jpg','jpeg','png']);
                                $isPdf = $ext === 'pdf';
                                ?>
                                <?php if($isImage): ?>
                                <div class="mt-1">
                                    <a href="<?php echo e($url); ?>" target="_blank" rel="noopener">
                                        <img src="<?php echo e($url); ?>"
                                            alt="Current Image"
                                            class="img-thumbnail"
                                            style="max-width:180px; max-height:180px;">
                                    </a>
                                </div>

                                
                                <?php elseif($isPdf): ?>
                                <div class="mt-2" style="max-width:300px; max-height:300px; overflow:hidden; border:1px solid #ddd;">
                                    <object data="<?php echo e($url); ?>" type="application/pdf" width="100%" height="250">
                                        <p>
                                            PDF preview unavailable.
                                            <a href="<?php echo e($url); ?>" target="_blank">Click to view PDF</a>
                                        </p>
                                    </object>
                                </div>
                                <a href="<?php echo e($url); ?>" target="_blank" class="btn btn-sm btn-outline-primary mt-1">
                                    View PDF
                                </a>

                                
                                <?php else: ?>
                                <p class="mb-1">File: <a href="<?php echo e($url); ?>" target="_blank"><?php echo e(basename($expense->file_path)); ?></a></p>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>

                        </div>
                       
                        <div class="form-group mb-0 row">
                            <div class="col-12 text-center">
                                <button type="submit" class="btn btn-info waves-effect waves-light" <?php if(!$canSubmit): echo 'disabled'; endif; ?>><?php echo e($buttonText); ?></button>
                                <button type="reset" class="btn btn-danger waves-effect waves-light"><?php echo e(__('global.reset')); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('backend/js/ajax-form-submit.js')); ?>"></script>
<script>
window.expensePaymentOptions = <?php echo json_encode($paymentOptions, 15, 512) ?>;
window.expensePaymentOptions.selectedAccount = <?php echo json_encode((int) old('account_id', $expense->account_id ?? 0), 512) ?>;
window.expensePaymentOptions.selectedPlatform = <?php echo json_encode((int) old('payment_platform_id', $expense->payment_platform_id ?? 0), 512) ?>;
</script>

<script src="<?php echo e(asset('backend/js/expense.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layoutsnew.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/arshad/Downloads/laravel/projects/expanseManager/resources/views/admin/expense/create.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="content">

    <!-- Start Content-->
    <div class="container-fluid">

        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Adminox</a></li>
                            <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e(__('users.permission')); ?></a></li>
                            <li class="breadcrumb-item active">New</li>
                        </ol>
                    </div>
                    <h4 class="page-title"><?php echo e(__('users.permission')); ?></h4>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="card-box">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="header-title mb-3"><?php echo e(__('users.manage_permission')); ?></h4>
                        <a href="<?php echo e(route('users.index')); ?>" class="btn btn-primary">
                            <?php echo e(__('global.back')); ?>

                        </a>
                    </div>
                    <?php if($user->hasRole('Super Admin')): ?>
                    <h4 class="text-bold">This user has Super Admin so no need to add <b>Permission</b></h4>
                    <?php else: ?>
                    <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
                    <h4>Manage Direct Permissions for User</h4>
                    <p><b>User Full Name:</b> <?php echo e($user->name); ?></p>
                    <p><b>User Id:</b> <?php echo e($user->id); ?></p>
                    <p><b>Email:</b> <?php echo e($user->email); ?></p>
                    <p><b>Role:</b> <?php echo e($user->roles->pluck('name')->implode(', ')); ?></p>
                    <p><b>Last Login:</b> <?php echo e($user->last_login_at); ?></p>
                    <form id="editRoleForm" method="POST" action="<?php echo e(route('users.permissions.update', $user)); ?>" class="data-ajax-submit form-horizontal">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?> 

                        <div class="card">
                            <div class="card-header">
                                Direct Permissions
                            </div>
                            <div class="card-body">
                                <div id="permissions-section" class="form-group row permissions-section">
                                    <div class="mb-3 col-12">
                                        <?php $__currentLoopData = $permissionsGrouped; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module => $permissions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="">
                                            
                                            <hr />
                                            <div class="form-check mb-2">
                                                <input type="checkbox"
                                                    id="module-<?php echo e(\Illuminate\Support\Str::slug($module)); ?>"
                                                    class="form-check-input module-checkbox"
                                                    data-module="<?php echo e(\Illuminate\Support\Str::slug($module)); ?>">
                                                <label class="form-check-label font-weight-bold text-dark"
                                                    for="module-<?php echo e(\Illuminate\Support\Str::slug($module)); ?>">
                                                    <?php echo e(ucfirst($module)); ?>

                                                </label>
                                            </div>

                                            
                                            <div class="row ml-3">
                                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $hasDirect = in_array($permission->id, $userDirectPermissions ?? []);
                                                    $hasViaRole = in_array($permission->id, $userRolePermissions ?? []);
                                                ?>
                                                <div class="col-md-2 mb-2">
                                                    <div class="form-check">
                                                        <input type="checkbox"
                                                            name="permissions[]"
                                                            value="<?php echo e($permission->id); ?>"
                                                            id="permission-<?php echo e($permission->id); ?>"
                                                            class="form-check-input permission-checkbox"
                                                            data-module="<?php echo e(\Illuminate\Support\Str::slug($module)); ?>"
                                                            <?php echo e(($hasDirect || $hasViaRole) ? 'checked' : ''); ?>>
                                                        <label class="form-check-label text-muted"
                                                            for="permission-<?php echo e($permission->id); ?>">
                                                            <?php echo e($permission->name); ?>

                                                        </label>
                                                    </div>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="mt-4 text-center">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.editPermission')): ?>
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('users.update_permission')); ?>

                            </button>
                            <?php endif; ?>
                            <a href="<?php echo e(route('users.list')); ?>" class="btn btn-secondary">
                                Cancel
                            </a>
                        </div>
                    </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('backend/js/permission-checkbox.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/ajax-form-submit.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layoutsnew.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/arshad/Downloads/laravel/projects/expanseManager/resources/views/admin/users/permissions/edit.blade.php ENDPATH**/ ?>
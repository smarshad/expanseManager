<!-- ========== Left Sidebar Start ========== -->
<div class="left-side-menu">

    <div class="slimscroll-menu">

        <!--- Sidemenu -->
        <!-- <div id="sidebar-menu">

            <ul class="metismenu" id="side-menu">

                <li class="menu-title">Navigation</li>

                <li>
                    <a href="javascript: void(0);">
                        <i class="fe-airplay"></i>
                        <span class="badge badge-success badge-pill float-right">2</span>
                        <span> Dashboard </span>
                    </a>
                    <ul class="nav-second-level" aria-expanded="false">
                        <li><a href="<?php echo e(route('dashboard1')); ?>">Dashboard 1</a></li>
                        <li> <a href="<?php echo e(route('dashboard2')); ?>">Dashboard 2</a></li>
                    </ul>
                </li>

                <li>
                    <a href="javascript: void(0);">
                        <i class="fe-airplay"></i>
                        <span class="menu-arrow"></span>
                        <span> Permissions </span>
                    </a>
                    <ul class="nav-second-level" aria-expanded="false">
                        <li><a href="<?php echo e(route('permissions.index')); ?>">View</a></li>
                        <li><a href="<?php echo e(route('permissions.create')); ?>">Create</a></li>
                    </ul>
                </li>
                <li>
                    <a href="javascript: void(0);">
                        <i class="fe-airplay"></i>
                        <span class="menu-arrow"></span>
                        <span> Users </span>
                    </a>
                    <ul class="nav-second-level" aria-expanded="false">
                        <li><a href="<?php echo e(route('users.index')); ?>">View</a></li>
                        <li><a href="<?php echo e(route('users.create')); ?>">Create</a></li>
                    </ul>
                </li>
                <li>
                    <a href="javascript: void(0);">
                        <i class="fe-airplay"></i>
                        <span class="menu-arrow"></span>
                        <span> Roles </span>
                    </a>
                    <ul class="nav-second-level" aria-expanded="false">
                        <li><a href="<?php echo e(route('roles.index')); ?>">View</a></li>
                        <li><a href="<?php echo e(route('roles.create')); ?>">Create</a></li>
                    </ul>
                </li>

                <li>
                    <a href="javascript: void(0);">
                        <i class="fe-lock"></i>
                        <span class="menu-arrow"></span>
                        <span> Expense </span>
                    </a>
                    <ul class="nav-second-level" aria-expanded="false">
                        <li><a href="<?php echo e(route('expense.index')); ?>">View</a></li>
                        <li><a href="<?php echo e(route('expense.create')); ?>">New</a></li>
                    </ul>
                </li>

                
                <li>
                    <a href="javascript: void(0);">
                        <i class="fe-folder-plus"></i>
                        <span> Multi Level </span>
                        <span class="menu-arrow"></span>
                    </a>
                    <ul class="nav-second-level nav" aria-expanded="false">
                        <li>
                            <a href="javascript: void(0);">Level 1.1</a>
                        </li>
                        <li>
                            <a href="javascript: void(0);" aria-expanded="false">Level 1.2
                                <span class="menu-arrow"></span>
                            </a>
                            <ul class="nav-third-level nav" aria-expanded="false">
                                <li>
                                    <a href="javascript: void(0);">Level 2.1</a>
                                </li>
                                <li>
                                    <a href="javascript: void(0);">Level 2.2</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </li>
    
            </ul>

        </div> -->

        <div id="sidebar-menu">

            <ul class="metismenu" id="side-menu">

                <li class="menu-title">Navigation</li>
                <li>
                    <a href="<?php echo e(route("month-end.index")); ?>">
                        <i class="fas fa-calendar-check"></i>
                        <span>Month-end Dashboard</span>
                    </a>
                </li>
                <?php $menuService = app('App\Services\MenuService'); ?>

                <?php
                $menus = $menuService->sidebarMenus(auth()->user());
                ?>

                <?php echo $__env->make('admin.partials.sidebar-menu', ['menus' => $menus], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <!-- End Sidebar -->
            </ul>
        </div>

        <div class="clearfix"></div>

    </div>
    <!-- Sidebar -left -->

</div>
<!-- Left Sidebar End --><?php /**PATH /home/arshad/Downloads/laravel/projects/expanseManager/resources/views/admin/partials/leftnavbar.blade.php ENDPATH**/ ?>
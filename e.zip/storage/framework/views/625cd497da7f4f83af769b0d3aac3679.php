<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('backend/libs/select2/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('backend/libs/bootstrap-select/bootstrap-select.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('backend/libs/select2/select2.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php
// Determine if we are in edit mode. Assume $menu is passed for editing.
$isEdit = isset($menu) && $menu->id;
$formAction = $isEdit  ? route('menu.update', $menu) : route('menu.store');
$pageTitle = $isEdit ? __('menu.edit_title') : __('menu.create_title');
$breadcrumbActive = $isEdit ? 'Edit' : 'New';
$buttonText = $isEdit ? __('global.update') : __('global.save');
$parent_id = $menu && $menu->exists ? $menu->parent_id : NULL
?>

<?php $__env->startSection('content'); ?>
<div class="content">

    <!-- Start Content-->
    <div class="container-fluid">

        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Adminox</a></li>
                            <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e(__('menu.title')); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo e($breadcrumbActive); ?></li>
                        </ol>
                    </div>
                    <h4 class="page-title"><?php echo e(__('menu.title')); ?></h4>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="card-box">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="header-title mb-3"><?php echo e($pageTitle); ?></h4>
                        <a href="<?php echo e(route('menu.index')); ?>" class="btn btn-primary">
                            <?php echo e(__('global.back')); ?>

                        </a>
                    </div>
                    <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
                    <form id="editRoleForm" action="<?php echo e($formAction); ?>" method="POST" class="data-ajax-submit form-horizontal">
                        <?php echo csrf_field(); ?>
                        <?php if($isEdit): ?>
                            <?php echo method_field('PUT'); ?>
                        <?php endif; ?>
                        <div class="row mb-3">
                            <label for="name" class="col-3 col-form-label">Menu Name <span class="text-danger">*</span></label>
                            <div class="col-3">
                                <input type="text" class="form-control" id="name" name="name" value="<?php echo e($menu && $menu->exists ? $menu->name : ''); ?>" placeholder="«Name»">
                            </div>
                            <label for="parent_id" class="col-3 col-form-label">Parent Menu</label>
                            <div class="col-3">
                                <select name="parent_id" id="parent_id" class="form-control">
                                    
                                    <option value="">-- Parent Menu --</option>

                                    <?php $__currentLoopData = $parentMenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($option['id']); ?>" <?php if($parent_id == $option['id']): ?> selected <?php endif; ?>>
                                        <?php echo e($option['name']); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="route" class="col-3 col-form-label">Laravel Route Name </label>
                            <div class="col-3">
                                <input type="text" class="form-control" id="route" name="route" placeholder="route" value="<?php echo e($menu && $menu->exists ? $menu->route : ''); ?>">
                                <div class="form-text">e.g., <code>menu.index</code></div>
                            </div>
                            <label for="url" class="col-3 col-form-label">External URL (Fallback)</label>
                            <div class="col-3">
                                <input type="text" class="form-control" id="url" name="url" placeholder="Url" value="<?php echo e($menu && $menu->exists ? $menu->url : ''); ?>">
                                <div class="form-text">e.g., <code>https://example.com</code></div>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="icon" class="col-3 col-form-label">Icon (Font Awesome Class)</label>
                            <div class="col-3">
                                <input type="text" class="form-control" id="icon" name="icon" placeholder="icon" value="<?php echo e($menu && $menu->exists ? $menu->icon : ''); ?>">
                                <div class="form-text">e.g., <code>fa-solid fa-house</code></div>
                            </div>
                            <label for="permission_id" class="col-3 col-form-label">Required Permission</label>
                            <div class="col-3">
                                <select class="form-control" id="permission_id" name="permission_id">
                                    <option value="">-- No Permission Required --</option>
                                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($permission->id); ?>" <?php echo e($menu->permission_id == $permission->id ? 'selected' : ''); ?>>
                                        <?php echo e($permission->name); ?> (<?php echo e($permission->module ?? 'N/A'); ?>)
                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="order" class="col-3 col-form-label">Order</label>
                            <div class="col-3">
                                <input type="number" class="form-control" id="order" name="order" placeholder="order" value="<?php echo e($menu && $menu->exists ? $menu->order : ''); ?>">
                            </div>
                            <label class="col-md-3 col-form-label" for="is_active">Is Active</label>
                            <div class="col-md-3 pt-10">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input" id="is_active" name="is_active" value="1" <?php echo e($menu->is_active == 1 ? 'checked' : ''); ?>>
                                    <label class="custom-control-label" for="is_active">&nbsp;</label>
                                </div>
                            </div>
                        </div>

                        <div class="row mb-0">
                            <div class="col-12 text-center">
                                <button type="submit" class="btn btn-primary waves-effect waves-light"><?php echo e($buttonText); ?> <?php echo e(__('menu.title')); ?></button>
                                <button type="reset" class="btn btn-danger waves-effect waves-light">Reset</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('backend/js/ajax-form-submit.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layoutsnew.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/arshad/Downloads/laravel/projects/expanseManager/resources/views/admin/menu/create.blade.php ENDPATH**/ ?>
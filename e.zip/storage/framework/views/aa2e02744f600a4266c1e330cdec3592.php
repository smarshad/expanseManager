<?php $__env->startSection('content'); ?>
<div class="home-btn d-none d-sm-block">
    <a href="<?php echo e(route('login')); ?>"><i class="fas fa-home h2 text-white"></i></a>
</div>
<div class="account-pages w-100 mt-5 mb-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6 col-xl-5">
                <div class="card mb-0">
                    <div class="card-body p-4">
                        <div class="account-box">
                            <div class="text-center account-logo-box">
                                <div>
                                    <a href="index.html">
                                        <img src="<?php echo e(asset('backend/images/logo-dark.png')); ?>" alt="" height="30">
                                    </a>
                                </div>
                            </div>
                            <div class="account-content mt-4">
                                <div class="text-center">
                                    <p class="text-muted mb-0 mb-3">Enter your email address and we'll send you an email with instructions to reset your password. </p>
                                </div>

                                <?php if($errors->any()): ?>

                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>

                                <?php endif; ?>
                                <?php if(session('status')): ?>
                                <div class="alert alert-success"><?php echo e(session('status')); ?></div>
                                <?php endif; ?>
                                <?php if(session('email')): ?>
                                <div class="alert alert-danger"><?php echo e(session('email')); ?></div>
                                <?php endif; ?>
                                <form class="form-horizontal" method="POST" action="<?php echo e(route('password.reset')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <!-- Password Reset Token -->
                                    <input type="hidden" name="token" value="<?php echo e($request->route('token')); ?>">
                                    <input type="hidden" name="email" value="<?php echo e($request->get('email')); ?>">
                                    <div class="form-group row">
                                        <div class="col-12">
                                            <label for="password">Password</label>
                                            <input class="form-control" id="password" type="password" name="password" required autocomplete="new-password">
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <div class="col-12">
                                            <label for="password_confirmation">Confirm Password</label>
                                            <input class="form-control" id="password_confirmation" type="password" name="password_confirmation" required autocomplete="confirm-password">
                                        </div>
                                    </div>

                                    <div class="form-group row text-center mt-2">
                                        <div class="col-12">
                                            <button class="btn btn-md btn-block btn-primary waves-effect waves-light" type="submit">Reset Password</button>
                                        </div>
                                    </div>

                                </form>
                                <div class="clearfix"></div>
                                <div class="row mt-4">
                                    <div class="col-sm-12 text-center">
                                        <p class="text-muted mb-0">Back to <a href="<?php echo e(route('login')); ?>" class="text-dark ml-1"><b>Sign In</b></a></p>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <!-- end card-box-->
                    </div>
                </div>
                <!-- end card-body -->
            </div>
            <!-- end card -->
        </div>
        <!-- end row -->
    </div>
    <!-- end container -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutsnew.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/arshad/Downloads/laravel/projects/expanseManager/resources/views/newauth/password/reset-password.blade.php ENDPATH**/ ?>
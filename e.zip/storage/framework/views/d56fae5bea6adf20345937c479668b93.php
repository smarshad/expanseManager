<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('backend/libs/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('backend/libs/datatables/dataTables.bootstrap4.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('backend/libs/datatables/buttons.bootstrap4.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('backend/libs/datatables/responsive.bootstrap4.css')); ?>" rel="stylesheet" type="text/css" />

<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('backend/libs/sweetalert2/sweetalert2.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/pages/sweet-alerts.init.js')); ?>"></script>

<script src="<?php echo e(asset('backend/libs/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/libs/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">

    <!-- Start Content-->
    <div class="container-fluid">

        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Adminox</a></li>
                            <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e(__('category.title')); ?></a></li>
                            <li class="breadcrumb-item active">All</li>
                        </ol>
                    </div>
                    <h4 class="page-title"><?php echo e(__('category.title')); ?></h4>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="card-box table-responsive">
                    <input type="hidden" id="listRoute" value="<?php echo e(route('category.list')); ?>">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="header-title mb-3"><?php echo e(__('category.all')); ?></h4>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category.create')): ?>
                        <button
                            class="btn btn-primary btn-sm openModel"
                            data-size="lg"
                            data-title="<?php echo e(__('global.new')); ?> <?php echo e(__('category.title')); ?>"
                            data-footer='<button type="submit" class="btn btn-primary waves-effect waves-light js-submit-btn"><?php echo e(__("global.new")); ?></button> <button type="button" class="btn btn-info waves-effect waves-light" data-dismiss="modal"><?php echo e(__("global.close")); ?></button>'
                            data-url="<?php echo e(route('category.create')); ?>">
                            + <?php echo e(__('global.new')); ?>

                        </button>
                        <?php endif; ?>
                    </div>
                    <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>

                    <div class="table-responsive">
                        <table id="datatable" class="table table-bordered  dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead>
                                <tr>
                                    <th>Sr No</th>
                                    <th>Category</th>
                                    <th>Parent</th>
                                    <th>Nature</th>
                                    <th>Budget Type</th>
                                    <th>Monthly Budget</th>
                                    <th>Is Active</th>
                                    <th>Created At</th>
                                    <th>Action</th>
                                </tr>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
    window.routes = {
        category_edit: "<?php echo e(route('category.edit', ':id')); ?>",
        delete: "<?php echo e(route('category.destroy', ':id')); ?>",
    };

    window.lang = {
        new: <?php echo json_encode(__('global.new'), 15, 512) ?>,
        edit: <?php echo json_encode(__('global.update'), 15, 512) ?>,
        close: <?php echo json_encode(__('global.close'), 15, 512) ?>,
        category_title: <?php echo json_encode(__('category.title'), 15, 512) ?>,
    };
</script>
<script src="<?php echo e(asset('backend/js/manage-category.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/ajax-form-submit.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layoutsnew.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/arshad/Downloads/laravel/projects/expanseManager/resources/views/admin/category/index.blade.php ENDPATH**/ ?>
<?php
    $isEdit = $category?->exists;
    $action = $isEdit ? route('category.update', $category) : route('category.store');
?>

<form id="categoryForm" action="<?php echo e($action); ?>" method="POST" class="data-ajax-submit form-horizontal">
    <?php echo csrf_field(); ?>
    <?php if($isEdit): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <div class="form-group row">
        <label class="col-md-4 col-form-label" for="parent_id">Parent Category</label>
        <div class="col-md-8">
            <select id="parent_id" name="parent_id" class="form-control">
                <option value="">Main Category</option>
                <?php $__currentLoopData = ($parentCategories ?? collect()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($parent->id); ?>" <?php if(old('parent_id', $category->parent_id ?? null) == $parent->id): echo 'selected'; endif; ?>>
                        <?php echo e($parent->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <small class="text-muted">Example: Groceries as parent, Vegetables as child.</small>
        </div>
    </div>

    <div class="form-group row">
        <label class="col-md-4 col-form-label" for="name">Name</label>
        <div class="col-md-8">
            <input type="text" id="name" name="name" class="form-control" value="<?php echo e(old('name', $category->name ?? '')); ?>" placeholder="Vegetables, Petrol, Medicines">
        </div>
    </div>

    <div class="form-group row">
        <label class="col-md-4 col-form-label" for="color_code">Color Code</label>
        <div class="col-md-8">
            <input type="text" id="color_code" name="color_code" class="form-control" maxlength="7" value="<?php echo e(old('color_code', $category->color_code ?? '')); ?>" placeholder="#28a745">
        </div>
    </div>

    <div class="form-group row">
        <label class="col-md-4 col-form-label" for="nature">Nature</label>
        <div class="col-md-8">
            <select id="nature" name="nature" class="form-control">
                <?php $__currentLoopData = ['need' => 'Need', 'want' => 'Want', 'investment' => 'Investment']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>" <?php if(old('nature', $category->nature ?? 'need') === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <div class="form-group row">
        <label class="col-md-4 col-form-label" for="budget_type">Budget Type</label>
        <div class="col-md-8">
            <select id="budget_type" name="budget_type" class="form-control">
                <?php $__currentLoopData = ['no_budget' => 'No Budget', 'soft_budget' => 'Soft Budget', 'hard_budget' => 'Hard Budget', 'fixed' => 'Fixed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>" <?php if(old('budget_type', $category->budget_type ?? 'soft_budget') === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <div class="form-group row">
        <label class="col-md-4 col-form-label" for="monthly_budget">Monthly Budget</label>
        <div class="col-md-8">
            <input type="number" step="0.01" min="0" id="monthly_budget" name="monthly_budget" class="form-control" value="<?php echo e(old('monthly_budget', $category->monthly_budget ?? '')); ?>" placeholder="Optional">
        </div>
    </div>

    <div class="form-group row">
        <label class="col-md-4 col-form-label" for="sort_order">Sort Order</label>
        <div class="col-md-8">
            <input type="number" min="0" id="sort_order" name="sort_order" class="form-control" value="<?php echo e(old('sort_order', $category->sort_order ?? 0)); ?>">
        </div>
    </div>

    <div class="form-group row">
        <label class="col-md-4 col-form-label" for="description">Description</label>
        <div class="col-md-8">
            <textarea id="description" name="description" class="form-control" placeholder="description"><?php echo e(old('description', $category->description ?? '')); ?></textarea>
        </div>
    </div>

    <div class="form-group row">
        <label class="col-md-4 col-form-label" for="is_active">Is Active</label>
        <div class="col-md-8 pt-10">
            <div class="custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input" id="is_active" name="is_active" value="1" <?php echo e(old('is_active', $category->is_active ?? true) ? 'checked' : ''); ?>>
                <label class="custom-control-label" for="is_active">&nbsp;</label>
            </div>
        </div>
    </div>
</form>
<?php /**PATH /home/arshad/Downloads/laravel/projects/expanseManager/resources/views/admin/category/_form.blade.php ENDPATH**/ ?>